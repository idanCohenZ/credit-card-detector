function [res] = untitled2(img)

% add an improvement to say there aren't credit card
res = 0;
% Convert the image to grayscale
gray_img = rgb2gray(img);


% Apply edge detection to the grayscale image
edges = edge(gray_img, 'Canny');

% Dilate the edges to connect any broken edges
dilated_edges = imdilate(edges, strel('rectangle', [3 3]));


% Find the rectangular regions in the dilated edges using regionprops
stats = regionprops(dilated_edges, 'BoundingBox');

results = ocr(img);
if contains(lower(results.Text), 'visa')
    res = 1;

% Loop through the regions and check if they contain digits or numbers
num_regions = 0;
for i = 1:length(stats)
    bbox = stats(i).BoundingBox;
    x1 = round(bbox(1));
    y1 = round(bbox(2));
    x2 = round(bbox(1) + bbox(3) - 1);
    y2 = round(bbox(2) + bbox(4) - 1);
    
    % Crop the region from the grayscale image
    region = gray_img(y1:y2, x1:x2);
    
    % Apply Otsu's method to the region to threshold it
    thresh = graythresh(region);
    bw = imbinarize(region, thresh);
   
    
    % Use OCR to check if the region contains digits or numbers
    ocr_result = ocr(bw, 'TextLayout', 'Block');
    if any(isstrprop(ocr_result.Text, 'digit')) || any(isstrprop(ocr_result.Text, 'alpha'))
        % Check if the region is contained within a larger rectangle
        contained = false;
        res = 1;
        for j = 1:length(stats)
            if j ~= i
                bbox2 = stats(j).BoundingBox;
                x1_2 = round(bbox2(1));
                y1_2 = round(bbox2(2));
                x2_2 = round(bbox2(1) + bbox2(3) - 1);
                y2_2 = round(bbox2(2) + bbox2(4) - 1);
                if x1 >= x1_2 && y1 >= y1_2 && x2 <= x2_2 && y2 <= y2_2
                    contained = true;
                    break;
                end
            end
        end
        if ~contained
            num_regions = num_regions + 1;
            regions(num_regions,:) = bbox;
        end
    else
        res = 0;
    end
   
end



% Draw the selected regions on the image
figure;
imshow(img);
hold on;
for i = 1:num_regions
    bbox = regions(i,:);
    rectangle('Position', [bbox(1), bbox(2), bbox(3), bbox(4)], 'EdgeColor', 'r', 'LineWidth', 2);
end

% Return the locations of the selected rectangles
locations = regions;


end